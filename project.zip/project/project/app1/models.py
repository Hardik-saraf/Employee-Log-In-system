from django.db import models

# Create your models here.
class shift(models.Model):
    Male = 'M'
    Female = 'F'
    ShiftA = 'MS'
    ShiftB = 'AS'
    ShiftC = 'ES'
    Gender = [
        (Male,'Male'),
        (Female,'Female')
    ]
    Shift = [
        (ShiftA, 'Shift A'),
        (ShiftB, 'Shift B'),
        (ShiftC, 'Shift C'),
    ]
    FirstName = models.CharField(max_length=100, default='')
    SecondName = models.CharField(max_length=100, default='')
    EmployeeID = models.CharField(max_length=20, primary_key=True)
    Gender = models.CharField(max_length = 20, choices= Gender, default='')
    Shift = models.CharField(max_length = 20, choices= Shift, default='')
    Start_Date = models.DateTimeField() 
    End_Date = models.DateTimeField()
    Timezone = models.CharField(max_length=100, default='')

    def __str__(self):
        return self.EmployeeID
