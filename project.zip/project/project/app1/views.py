from django.shortcuts import render,HttpResponse
from app1.models import shift

# Create your views here.

def index(request):
    return render(request, "home.html")
    # return HttpResponse('Is this working???')

def cal(request):
    res = 0
    if request.method == "POST":
        x = int(request.POST['Total_Resource'])
        y = int(request.POST['No_Of_Shifts'])
        z = int(request.POST['Per_Shift_Resource'])
        res = (z+1)*y    
    return render(request,'cal.html',{'result':res})

# def result(request):
#     return render(request,"result.html")

def roster(request):
    if request.method == "POST":
        FirstName = request.POST['FirstName']
        SecondName = request.POST['SecondName']
        EmployeeID = request.POST['EmployeeID']
        Gender = request.POST['Gender']
        Shift = request.POST['Shift']
        Start_Date = request.POST["Start_Datetime"]
        End_Date = request.POST["End_Datetime"]
        Timezone = request.POST["Timezone"]
        # Gender = request.POST.get('Gender')
        # Shift = request.POST.get('Shift')
        # print(FirstName, SecondName, EmployeeID,Gender,Shift,Start_Date,End_Date,Timezone)
        # Start_Date = request.POST.get('Start_Date')
        # End_Date = request.POST.get('End_Date')
        # shift = shift(FirstName = FirstName,SecondName = SecondName,
        # EmployeeID=EmployeeID)
        # shift.save()
        data = shift(Gender=Gender, FirstName=FirstName, SecondName=SecondName, EmployeeID=EmployeeID, Shift=Shift, Start_Date=Start_Date, End_Date=End_Date,  Timezone=Timezone
        )
        data.save()
        
    return render(request,"roster.html")