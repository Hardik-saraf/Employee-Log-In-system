from django.contrib import admin
from django.urls import path
from app1 import views

urlpatterns = [
    path('', views.index, name='index'),
    path('cal',views.cal, name='cal'),
    path('roster',views.roster, name='roster'),
    # path('result', views.result, name='result'),
]